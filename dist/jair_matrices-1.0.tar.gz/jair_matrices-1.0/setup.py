from setuptools import setup

setup(name='jair_matrices',
      version='1.0',
      description='Matrix basic operation',
      packages=['jair_matrices'],
      zip_safe=False)
